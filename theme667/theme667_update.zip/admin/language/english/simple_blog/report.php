<?php
// Heading
$_['heading_title']  		= 'Blog Viewed Report';

// Text
$_['text_success']   		= 'Success: You have modified the blog viewed report!';

// Column
$_['column_article_name']	= 'Article Name';
$_['column_author_name']	= 'Author Name';
$_['column_viewed']  		= 'Viewed';
$_['column_percent'] 		= 'Percent';

// Entry
$_['entry_date_start']  	= 'Date Start:';
$_['entry_date_end']    	= 'Date End:';

?>