<?php

class ControllerModuleTMParallax extends Controller
{
	public function index($setting)
	{
		static $module = 0;

		$this->load->model('design/banner');
		$this->load->model('tool/image');

		$this->document->addScript('catalog/view/javascript/tmparallax/jquery.rd-parallax.min.js');
		$this->document->addStyle('catalog/view/javascript/tmparallax/css/rd-parallax.css');

		if (is_file(DIR_IMAGE . $setting['image'])) {
			$data['image'] = $this->model_tool_image->resize($setting['image'], $setting['width'], $setting['height']);
		} else {
			$data['image'] = '';
		}

		if ($setting['speed']) {
			$data['speed'] = $setting['speed'];
		} else {
			$data['speed'] = '0.2';
		}

		if ($setting['direction']) {
			$data['direction'] = 'normal';
		} else {
			$data['direction'] = 'inverse';
		}

		if ($setting['blur']) {
			$data['blur'] = 'true';
		} else {
			$data['blur'] = 'false';
		}


		$this->load->model('extension/module');
		$data['layers'] = array();

		if (isset($setting['layers']) && $setting['layers']) {
			$i=0;
			foreach ($setting['layers'] as $layer) {

				$data['layers'][$i] = array(
					'type' => $layer['type'] == 0 ? 'html' : 'media',
					'description' => html_entity_decode($layer['description'][$this->config->get('config_language_id')], ENT_QUOTES, 'UTF-8'),
					'speed' => $layer['speed'],
					'fade' => $layer['fade'] == 0 ? 'false' : 'true',
					'direction' => $layer['direction'] == 0 ? 'inverse' : 'normal'
					);

				if (isset($layer['image']) && $layer['image']) {
					$data['layers'][$i]['image'] = $this->model_tool_image->resize($layer['image'], $layer['width'], $layer['height']);
					$data['layers'][$i]['blur'] = $layer['blur'] == 0 ? 'false' : 'true';
				}

				if (isset($layer['module_id'])) {
					foreach ($layer['module_id'] as $module) {
						$code = $this->model_extension_module->getModuleCode($module);
						$setting_info = $this->model_extension_module->getModule($module);
						if ($setting_info && $setting_info['status']) {
							$data['layers'][$i]['modules'][] = $this->load->controller('module/' . $code, $setting_info);
						}
					}
				}
				$i++;
			}
		}

		$data['module_counter'] = $module++;

		if (file_exists(DIR_TEMPLATE . $this->config->get('config_template') . '/template/module/tm_parallax.tpl')) {
			return $this->load->view($this->config->get('config_template') . '/template/module/tm_parallax.tpl', $data);
		} else {
			return $this->load->view('default/template/module/tm_parallax.tpl', $data);
		}
	}
}