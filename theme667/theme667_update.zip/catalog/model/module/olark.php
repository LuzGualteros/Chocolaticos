<?php

class ModelModuleOlark extends Model {
	
}

