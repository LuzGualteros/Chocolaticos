<?php
// Heading
$_['heading_title'] = 'Топ Продукты';

// Text
$_['text_tax']      = 'Без НДС:';

