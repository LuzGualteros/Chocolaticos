<?php

// Heading 
$_['heading_title']      	= 'Blog';

$_['text_date_format']		= 'd.m.y';

$_['text_popular_all']		= 'Popular Articles';
$_['text_latest_all']		= 'Latest Articles';
$_['text_button_continue']	= 'Read More';
$_['text_comments']	= ' Comments';
$_['text_comment']	= ' Comment';



$_['text_no_result']		= 'No Result!';

?>